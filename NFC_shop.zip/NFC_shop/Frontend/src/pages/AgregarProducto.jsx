import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../styles/AgregarProducto.css";

export default function AgregarProducto() {

  const [exito, setExito] = useState(false);
  const navigate = useNavigate();

  const mostrarMensaje = () => {
    setExito(true);

    // OPCIONAL: redirigir después de 2 segundos
    // setTimeout(() => navigate("/almacen"), 2000);
  };

  return (
    <div className="agregar-wrapper">

      {/* TOP BAR */}
      <div className="agregar-topbar">
        <Link to="/almacen" className="back-btn">⬅</Link>
        Nuevo Producto
        <div></div>
      </div>

      {/* CARD */}
      <div className="agregar-card">

        {/* Emoji */}
        <div className="agregar-emoji">🛒</div>

        <h2 className="agregar-title">Agregar Producto al Almacén</h2>

        {/* FORMULARIO */}
        <div className="formulario">

          <div className="campo">
            <label>Nombre del Producto</label>
            <input type="text" placeholder="Ej: Manzanas Rojas" />
          </div>

          <div className="campo">
            <label>Precio (S/)</label>
            <input type="number" placeholder="Ej: 2.50" />
          </div>

          <div className="campo">
            <label>Categoría</label>
            <select>
              <option>Frutas</option>
              <option>Lácteos</option>
              <option>Panadería</option>
              <option>Bebidas</option>
              <option>Granos</option>
              <option>Carnes</option>
            </select>
          </div>

          <div className="campo">
            <label>Stock</label>
            <input type="number" placeholder="Ej: 50" />
          </div>

          <div className="campo">
            <label>Fecha de Vencimiento</label>
            <input type="date" />
          </div>

        </div>

        {/* BOTONES */}
        <div className="agregar-buttons">
          <Link to="/almacen">
            <button className="btn-cancelar">Cancelar</button>
          </Link>

          <button className="btn-guardar" onClick={mostrarMensaje}>
            Guardar Producto ✔
          </button>
        </div>

      </div>

      {/* MENSAJE DE ÉXITO */}
      {exito && (
        <div className="mensaje-exito">
          <div className="mensaje-card">
            <div className="mensaje-emoji">✔️</div>
            <h3>¡Producto guardado exitosamente!</h3>

            <button
              className="mensaje-btn"
              onClick={() => navigate("/almacen")}
            >
              OK
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
